# Changelog

Alla viktiga ändringar i detta projekt dokumenteras i denna fil.

## [0.2.0] – 2025-08-06

### Added

* Implementerade paketöversikt i admin. Sektionen “Packages” visar nu alla definierade repositoryn med information om huruvida motsvarande plugin eller tema är installerat samt vilken version som är installerad. Senaste version och uppdateringsfunktioner kommer i en senare version.

### Changed

* Uppdaterade pluginversion till 0.2.0.

## [0.3.0] – 2025-08-06

### Added

* Paketöversikten visar nu den senaste release-versionen från GitHub för varje definierat repo. Detta hämtas via GitHub API och kräver att en giltig token sparats i inställningarna.

### Changed

* Uppdaterade pluginversion till 0.3.0.


## [0.1.0] – 2025-08-06

### Added

* Första versionen av GitFetch med grundläggande struktur.
* Inställningssida för att spara GitHub‑token.
* GUI för att lägga till och ta bort repo med ägare, namn och typ.
* Skelett för GitHub API‑klient och Upgrader.
* Rensningsrutin vid avinstallation som tar bort plugin‑specifika alternativ.
* Licensfil (GPLv2) och README.

## Older versions

Ingen.