# Changelog

Alla viktiga ändringar i detta projekt dokumenteras i denna fil.

## [0.1.0] – 2025-08-06

### Added

* Första versionen av GitFetch med grundläggande struktur.
* Inställningssida för att spara GitHub‑token.
* GUI för att lägga till och ta bort repo med ägare, namn och typ.
* Skelett för GitHub API‑klient och Upgrader.
* Rensningsrutin vid avinstallation som tar bort plugin‑specifika alternativ.
* Licensfil (GPLv2) och README.

## Older versions

Ingen.