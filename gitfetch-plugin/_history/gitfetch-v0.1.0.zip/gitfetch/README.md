# GitFetch

GitFetch är ett WordPress‑plugin som låter dig ansluta till privata GitHub‑repositorier, jämföra versioner av teman och plugins, se README och CHANGELOG och installera uppdateringar direkt från admin. Pluginet är designat för egenutvecklade projekt där versioner lagras i GitHub och distribueras utanför WordPress.org.

## Funktioner

* Lagra en GitHub Personal Access Token för autentiserade API‑anrop.
* Lägg till flera GitHub‑repo via admin och märk dem som plugin eller tema.
* Visa en lista över dina repo med möjlighet att ta bort dem.
* (Planned) Jämför installerad version med senaste release på GitHub och installera uppdateringar eller tidigare versioner.
* (Planned) Visa `README.md` och `CHANGELOG.md` från repo i admin.
* (Planned) Rensa gamla plugin‑data vid avinstallation.

## Installation

1. Ladda ner GitFetch‑zipfilen och installera den via **Tillägg → Lägg till nytt → Ladda upp tillägg** i WordPress.
2. Aktivera pluginet.
3. Gå till **GitFetch** i administratörsmenyn och ange din GitHub‑token.
4. Lägg till de repo du vill spåra genom att ange ägare (owner), repots namn och välja om det är ett plugin eller tema.

> **Observera:** GitFetch är avsett för privat användning och följer inte WordPress.orgs regler för distribution av plugins som installerar kod från externa källor【38248605680118†L256-L263】. Ditt GitHub‑konto måste ha behörighet till de repo du lägger till.

## Vanliga frågor

### Vilka är kraven?

* WordPress 6.0 eller senare.
* PHP 7.4 eller senare.
* En GitHub Personal Access Token med tillgång till de repo du vill använda.

### Är pluginet säkert att använda?

Pluginet använder WordPress HTTP‑API för alla anrop【655874743635771†L70-L100】 och kontrollerar paketet via WordPress’ inbyggda uppgraderingsklass【659666605620511†L96-L156】. Det är dock fortfarande ditt ansvar att säkerställa att koden i ditt repo är trygg.

### Hur kan jag bidra?

Du kan bidra med buggrapporter, förslag eller pull requests på GitHub‑projektet.

## Licens

GitFetch är fri programvara och licensieras under GPLv2 eller senare. Se `LICENSE` för fullständig licenstext.